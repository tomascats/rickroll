# rickroll
<strong> https://ajsya.github.io/rickroll/ </strong>

Rickroll your friends by sending them to this website that autoplays "Never Gonna Give You Up" by Rick Astley in fullscreen for optimal rickrolling.
